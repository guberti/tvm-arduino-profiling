#include <tvm/runtime/crt/module.h>
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_12(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_19(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_6(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_23(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_15(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_5(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_2(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_8(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_7(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_22(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_10(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_16(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_14(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_9(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_11(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_cast_subtract(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_add_clip_cast(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_20(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_18(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_24(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_25(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_1(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_21(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_4(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_3(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_13(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_avg_pool2d_cast_cast(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_17(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_26(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t _lookup_linked_param(TVMValue* args, int* type_code, int num_args, TVMValue* out_value, int* out_type_code);
static TVMBackendPackedCFunc _tvm_func_array[] = {
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_12,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_19,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_6,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_23,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_15,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_5,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_2,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_8,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_7,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_22,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_10,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_16,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_14,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_9,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_11,
    (TVMBackendPackedCFunc)tvmgen_default_fused_cast_subtract,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_add_clip_cast,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_20,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_18,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_24,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_25,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_1,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_21,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_4,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_3,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_13,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_avg_pool2d_cast_cast,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_17,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_26,
    (TVMBackendPackedCFunc)tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast,
    (TVMBackendPackedCFunc)_lookup_linked_param,
};
static const TVMFuncRegistry _tvm_func_registry = {
    "\037tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_12\000tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_19\000tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_6\000tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_23\000tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_15\000tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_5\000tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_2\000tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_8\000tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_7\000tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_22\000tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_10\000tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_16\000tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_14\000tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_9\000tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_11\000tvmgen_default_fused_cast_subtract\000tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_add_clip_cast\000tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_20\000tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_18\000tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_24\000tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_25\000tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_1\000tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_21\000tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_4\000tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_3\000tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_13\000tvmgen_default_fused_nn_avg_pool2d_cast_cast\000tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_17\000tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast_26\000tvmgen_default_fused_nn_conv2d_add_fixed_point_multiply_clip_cast_cast\000_lookup_linked_param\000",    _tvm_func_array,
};
static const TVMModule _tvm_system_lib = {
    &_tvm_func_registry,
};
const TVMModule* TVMSystemLibEntryPoint(void) {
    return &_tvm_system_lib;
}
;